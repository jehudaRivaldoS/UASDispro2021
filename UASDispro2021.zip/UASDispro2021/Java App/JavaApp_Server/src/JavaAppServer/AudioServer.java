/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaAppServer;

/**
 *
 * @author Acer
 */
public class AudioServer {

    public static boolean calling = false;
    public static void main(String[] args) {
        FormAudioServer fr = new FormAudioServer();
        fr.setVisible(true);
    }
    
}
